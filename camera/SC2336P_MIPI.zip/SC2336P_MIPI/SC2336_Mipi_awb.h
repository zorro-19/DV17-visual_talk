
#ifndef __SC2336_MIPI_AWB_H__
#define __SC2336_MIPI_AWB_H__

#include "asm/isp_alg.h"

#define AWB_ALG_TYPE    AWB_ALG_GW1
//#define AWB_ALG_TYPE    AWB_ALG_HYBRID
#define AWB_WIN_TYPE    AWB_WIN_WEIGHT_AVG
#define AWB_SCENE_TYPE  AWB_AUTO


#endif
